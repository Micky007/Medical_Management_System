# Medical_Management_System
This project is related to Health sector, as every one gets sick atleast ones in a month. At that time it is not posiible to keep all the record of your health in paper format here the Medical management System comes to help by keeping all medical in a database of a central system across counrty 
